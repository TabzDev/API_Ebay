# app.py

import csv
import io
from statistics import mean, median
from flask import Flask, render_template, request, send_file
from Extract_data_ebay import fetch_ebay_data

# I create the Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    # I initialize my data holders
    items, chart_data = [], []
    stats, query, error = {}, "", None

    if request.method == 'POST':
        query = request.form.get('keyword', '').strip()
        if not query:
            error = "Please enter a card name."
        else:
            items, chart_data = fetch_ebay_data(query)
            if not items:
                error = "No listings found in the last 90 days."
            else:
                sold_prices = [i["price"] for i in items if i["price"] is not None]
                if sold_prices:
                    # I compute basic stats
                    stats = {
                        "mean":   round(mean(sold_prices), 2),
                        "median": round(median(sold_prices), 2),
                        "min":    min(sold_prices),
                        "max":    max(sold_prices),
                        "count":  len(sold_prices)
                    }

    # I render the page, passing all data to the template
    return render_template('index.html',
                           items=items,
                           chart_data=chart_data,
                           stats=stats,
                           query=query,
                           error=error)

@app.route('/download.csv')
def download_csv():
    # I generate a CSV of the current query's results
    q = request.args.get('q', '')
    items, _ = fetch_ebay_data(q)

    si = io.StringIO()
    writer = csv.writer(si)
    writer.writerow(["Title","Price (GBP)","Sold Date","Condition","Link"])
    for i in items:
        writer.writerow([
            i["title"],
            i["price"] or "Not sold",
            i["sold_date"],
            i["condition"],
            i["link"]
        ])

    mem = io.BytesIO()
    mem.write(si.getvalue().encode())
    mem.seek(0)

    # I send the CSV to the user
    return send_file(mem,
                     as_attachment=True,
                     download_name=f"{q}_sales.csv",
                     mimetype="text/csv")

if __name__ == '__main__':
    # I start the Flask dev server
    app.run(debug=True)
