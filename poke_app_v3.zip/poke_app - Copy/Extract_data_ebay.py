# Extract_data_ebay.py

import logging
import time
import re
from functools import lru_cache
from datetime import datetime, timedelta
from collections import defaultdict
import requests
from typing import List, Dict, Tuple

# I set up logging so I can see warnings and errors in the console
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# My RapidAPI credentials (replace with yours if needed)
RAPIDAPI_KEY = "c7a432d6f4msh41c21884e07ec55p170de8jsnf9bfb200ab3f"
RAPIDAPI_HOST = "ebay-average-selling-price.p.rapidapi.com"
API_URL = f"https://{RAPIDAPI_HOST}/findCompletedItems"


def parse_shipping(shipping_price) -> float:
    # I extract a numeric shipping fee from whatever the API returns
    if shipping_price is None:
        return 0.0
    text = str(shipping_price)
    m = re.search(r"(\d+\.?\d*)", text)
    if m:
        return float(m.group(1))
    return 0.0


def retry_request(payload: dict, headers: dict, retries: int = 3) -> dict:
    # I retry the POST up to 3 times, waiting longer each time
    delay = 1
    for attempt in range(1, retries + 1):
        try:
            response = requests.post(API_URL, json=payload, headers=headers, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.warning(f"Attempt {attempt} failed: {e}")
            time.sleep(delay)
            delay *= 2
    logger.error("All retry attempts failed.")
    return {}


@lru_cache(maxsize=128)
def fetch_ebay_data(keyword: str) -> Tuple[List[Dict], List[Dict]]:
    # I fetch Pokémon card listings (sold/ended) from the last 90 days
    cutoff = datetime.utcnow() - timedelta(days=90)

    # Prepare headers and payload
    headers = {
        "Content-Type": "application/json",
        "x-rapidapi-host": RAPIDAPI_HOST,
        "x-rapidapi-key": RAPIDAPI_KEY
    }
    payload = {
        "keywords": keyword,
        "max_search_results": "240",
        "category_id": "183454",
        "remove_outliers": "false",
        "site_id": "3",
        "aspects": []
    }

    # I send the request, with retries
    data = retry_request(payload, headers)
    products = data.get("products", [])

    items = []
    daily_prices = defaultdict(list)

    for p in products:
        raw_date = p.get("date_sold") or p.get("end_date")
        if not raw_date:
            continue
        try:
            sold_dt = datetime.strptime(raw_date, "%d %b %Y")
        except ValueError:
            continue
        if sold_dt < cutoff:
            continue
        day = sold_dt.strftime("%Y-%m-%d")

        sale_price = p.get("sale_price") or 0.0
        shipping_fee = parse_shipping(p.get("shipping_price"))
        total_price = round(sale_price + shipping_fee, 2)

        # I only include sold items in the price chart
        if sale_price > 0:
            daily_prices[day].append(total_price)

        items.append({
            "title":     p.get("title", "N/A"),
            "price":     total_price if sale_price > 0 else None,
            "sold_date": day,
            "condition": p.get("condition", "N/A"),
            "link":      p.get("link", "#"),
            "image_url": p.get("image_url", "")
        })

    chart_data = []
    for day in sorted(daily_prices):
        prices = daily_prices[day]
        avg = round(sum(prices) / len(prices), 2)
        chart_data.append({"date": day, "avg_price": avg, "volume": len(prices)})

    return items, chart_data
