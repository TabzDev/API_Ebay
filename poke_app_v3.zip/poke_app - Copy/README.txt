PokeTrader — 90-Day Pokémon Card Listings
==========================================

What is this?
-------------
I built PokeTrader so you can type any Pokémon card name
(e.g. "Charizard EX 199/165") and see all eBay UK listings
that sold or ended in the last 90 days. You’ll see:
 • Exact total price in GBP (sale + shipping)
 • Sold/ended date
 • Card condition
 • A “View” link to the eBay listing
 • A chart: green line = average price, yellow bars = volume

Setup & Run
-----------
1. Install Python 3.8+.
2. Open a terminal here.
3. Install requirements:
     pip install -r requirements.txt
4. Add your RapidAPI key:
   • Open Extract_data_ebay.py
   • Replace RAPIDAPI_KEY with your key.
5. Start the app:
     python app.py
6. Go to:
     http://127.0.0.1:5000

How to Use
----------
 • Enter a Pokémon card name → click Search.
 • Spinner shows while I load data.
 • Stats appear (mean, median, min, max, count).
 • Chart shows price & volume over time.
 • Table lists every item. “Not sold” means no sale.
 • Click “View” for the eBay listing.
 • Download CSV if you need the raw data.

Dependencies Explained
----------------------
 • Flask: my web framework (routes & templates).
 • requests: my HTTP client for RapidAPI.

Tips & Caveats
------------
 • I cache searches and retry requests to handle rate limits.
 • If you hit limits, wait ~30s then try again.
 • Listings without sales show “Not sold.”
 • For a production app, add SSL, WSGI (Gunicorn), and secure the key.

Enjoy PokeTrader! 🎉
